<?php
class Storage {

    const DIRECTORY = "./data";

    const QUANTITY = 65535;

    const SPACE = 256 *1024;

    const TIMEOUT = 15 *60;

    const CORS = [
        "Access-Control-Allow-Origin" => "*",
        "Access-Control-Allow-Credentials" => "true",
        "Access-Control-Max-Age" => "86400",
        "Access-Control-Expose-Headers" => "*"
    ];

    private $storage;

    private $root;

    private $store;

    private $share;

    private $xml;

    private $xpath;

    private $options;

    private $revision;

    private $serial;

    private $unique;

    const PATTERN_HTTP_REQUEST = "/^([A-Z]+)\s+(.+)\s+(HtTP\/\d+(?:\.\d+)*)$/i";

    const PATTERN_HTTP_REQUEST_URI = "/^(.*?)[!#\$\*:\?@\|~]+(.*)$/i";

    const PATTERN_HEADER_STORAGE = "/^(\w{1,64})(?:\s+(\w+)){0,1}$/";

    const PATTERN_XPATH_OPTIONS = "/^(.*?)((?:!+\w+){0,})$/";

    const PATTERN_XPATH_ATTRIBUTE = "/((?:^\/+)|(?:^.*?))\/{0,}(?<=\/)(?:@|attribute::)(\w+)$/i";

    const PATTERN_XPATH_PSEUDO = "/^(.*?)(?:::(before|after|first|last)){0,1}$/i";

    const PATTERN_XPATH_FUNCTION = "/^[\(\s]*[^\/\.\s\(].*$/";

    const CONTENT_TYPE_TEXT  = "text/plain";
    const CONTENT_TYPE_XPATH = "text/xpath";
    const CONTENT_TYPE_HTML  = "text/html";
    const CONTENT_TYPE_XML   = "application/xslt+xml";
    const CONTENT_TYPE_JSON  = "application/json";

    function __construct($storage = null, $root = null, $xpath = null) {

        $options = [];
        if (preg_match(Storage::PATTERN_XPATH_OPTIONS, $xpath, $matches, PREG_UNMATCHED_AS_NULL)) {
            $xpath = $matches[1];
            $options = array_merge(array_filter(explode("!", strtolower($matches[2]))));
        }

        $this->storage  = $storage;
        $this->root     = $root ? $root : "data";
        $this->store    = Storage::DIRECTORY . "/" . base64_encode($this->storage);
        $this->xpath    = $xpath;
        $this->options  = $options;
        $this->unique   = Storage::uniqueId();
        $this->serial   = 0;
        $this->revision = 0;
    }

    private static function uniqueId() {

        $unique = base_convert($_SERVER["REMOTE_PORT"], 10, 36);
        $unique = str_pad($unique, 4, 0, STR_PAD_LEFT);
        $unique = base_convert(round(microtime(true) *1000), 10, 36) . $unique;
        return strtoupper($unique);
    }

    private static function cleanUp() {

        if (!is_dir(Storage::DIRECTORY))
            return;
        if ($handle = opendir(Storage::DIRECTORY)) {
            $timeout = time() -Storage::TIMEOUT;
            while (($entry = readdir($handle)) !== false) {
                if ($entry == "."
                        || $entry == "..")
                    continue;
                $entry = Storage::DIRECTORY . "/$entry";
                if (filemtime($entry) > $timeout)
                    continue;
                if (file_exists($entry))
                    @unlink($entry);
            }
            closedir($handle);
        }
    }

    static function share($storage, $xpath, $exclusive = true) {

        if (!preg_match(Storage::PATTERN_HEADER_STORAGE, $storage))
            (new Storage)->quit(400, "Bad Request", ["Message" => "Invalid storage identifier"]);

        $root = preg_replace(Storage::PATTERN_HEADER_STORAGE, "$2", $storage);
        $storage = preg_replace(Storage::PATTERN_HEADER_STORAGE, "$1", $storage);

        Storage::cleanUp();
        if (!file_exists(Storage::DIRECTORY)) {
             mkdir(Storage::DIRECTORY, true);
             chmod(Storage::DIRECTORY, 0755);
        }
        $storage = new Storage($storage, $root, $xpath);

        if ($storage->exists()) {
            $storage->open($exclusive);
            if (($root ? $root : "data") != $storage->xml->documentElement->nodeName)
                $storage->quit(404, "Resource Not Found");
        }
        return $storage;
    }

    private function exists() {
        return file_exists($this->store)
                && filesize($this->store) > 0;
    }

    private function open($exclusive = true) {

        if ($this->share !== null)
            return;

        touch($this->store);
        $this->share = fopen($this->store, "c+");
        flock($this->share, filesize($this->store) <= 0 || $exclusive === true ? LOCK_EX : LOCK_SH);

        if (filesize($this->store) <= 0) {
            fwrite($this->share,
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" .
            "<" . $this->root . " ___rev=\"0\" ___uid=\"" . $this->getSerial() . "\"/>");
            rewind($this->share);
        }

        fseek($this->share, 0, SEEK_END);
        $size = ftell($this->share);
        rewind($this->share);
        $this->xml = new DOMDocument();
        $this->xml->loadXML(fread($this->share, $size));
        $this->revision = $this->xml->documentElement->getAttribute("___rev");
    }

    function materialize() {

        if ($this->share == null)
            return;
        if ($this->revision == $this->xml->documentElement->getAttribute("___rev"))
            return;

        $output = $this->xml->saveXML();
        if (strlen($output) > Storage::SPACE)
            $this->quit(413, "Payload Too Large");
        ftruncate($this->share, 0);
        rewind($this->share);
        fwrite($this->share, $output);
    }

    function close() {

        if ($this->share == null)
            return;

        flock($this->share, LOCK_UN);
        fclose($this->share);

        $this->share = null;
        $this->xml = null;
    }

    private function getSerial() {
        return $this->unique . ":" . $this->serial++;
    }

    private function getSize() {

        if ($this->xml !== null)
            return strlen($this->xml->saveXML());
        if ($this->share !== null)
            return filesize($this->share);
        if ($this->store !== null
                && file_exists($this->store))
            return filesize($this->store);
        return 0;
    }

    private static function updateNodeRevision($node, $revision) {

        while ($node && $node->nodeType === XML_ELEMENT_NODE) {
            $node->setAttribute("___rev", $revision);
            $node = $node->parentNode;
        }
    }

    function doConnect() {

        if (!empty($this->xpath))
            $this->quit(400, "Bad Request", ["Message" => "Invalid XPath"]);

        $response = [201, "Created"];
        if (!$this->exists()) {
            $iterator = new FilesystemIterator(Storage::DIRECTORY, FilesystemIterator::SKIP_DOTS);
            if (iterator_count($iterator) >= Storage::QUANTITY)
                $this->quit(507, "Insufficient Storage");
            $this->open(true);
        } else $response = [202, "Accepted"];

        $this->materialize();
        $this->quit($response[0], $response[1], ["Connection-Unique" => $this->unique]);
    }

    function doOptions() {

        if (empty($this->xpath))
            $this->doConnect();

        if (!$this->exists())
            $this->quit(404, "Resource Not Found");

        if (empty($this->xpath))
            $this->quit(400, "Bad Request", ["Message" => "Invalid XPath"]);

        libxml_use_internal_errors(true);
        libxml_clear_errors();

        $allow = "CONNECT, OPTIONS, GET, POST, PUT, PATCH, DELETE";

        if (preg_match(Storage::PATTERN_XPATH_FUNCTION, $this->xpath)) {
            $result = (new DOMXpath($this->xml))->evaluate($this->xpath);
            if (Storage::fetchLastXmlErrorMessage()) {
                $message = "Invalid XPath function (" . Storage::fetchLastXmlErrorMessage() . ")";
                $this->quit(400, "Bad Request", ["Message" => $message]);
            }
            $allow = "CONNECT, OPTIONS, GET, POST";
        } else {
            $targets = (new DOMXpath($this->xml))->query($this->xpath);
            if (Storage::fetchLastXmlErrorMessage()) {
                $message = "Invalid XPath axis (" . Storage::fetchLastXmlErrorMessage() . ")";
                $this->quit(400, "Bad Request", ["Message" => $message]);
            }
            if ($targets && !empty($targets) && $targets->length > 0) {
                $serials = [];
                foreach ($targets as $target) {
                    if ($target instanceof DOMAttr)
                        $target = $target->parentNode;
                    if ($target instanceof DOMElement)
                        $serials[] = $target->getAttribute("___uid");
                }
                if (!empty($serials))
                    header("Storage-Effects: " . join(" ", $serials));
                $allow = "CONNECT, OPTIONS, GET, POST, PUT, PATCH, DELETE";

            } else $allow = "CONNECT, OPTIONS, PUT";
        }

        $this->quit(204, "No Content", ["Allow" => $allow]);
    }

    function doGet() {

        if (!$this->exists())
            $this->quit(404, "Resource Not Found");

        if (empty($this->xpath))
            $this->quit(400, "Bad Request", ["Message" => "Invalid XPath"]);

        libxml_use_internal_errors(true);
        libxml_clear_errors();

        if (preg_match(Storage::PATTERN_XPATH_FUNCTION, $this->xpath))
            $result = (new DOMXpath($this->xml))->evaluate($this->xpath);
        else $result = (new DOMXpath($this->xml))->query($this->xpath);
        if (Storage::fetchLastXmlErrorMessage()) {
            $message = "Invalid XPath";
            if (preg_match(Storage::PATTERN_XPATH_FUNCTION, $this->xpath))
                $message = "Invalid XPath function";
            $message .= " (" . Storage::fetchLastXmlErrorMessage() . ")";
            $this->quit(400, "Bad Request", ["Message" => $message]);
        } else if (!preg_match(Storage::PATTERN_XPATH_FUNCTION, $this->xpath)
                &&  (!$result || empty($result) || $result->length <= 0)) {
            $this->quit(404, "Resource Not Found");
        } else if ($result instanceof DOMNodeList) {
            if ($result->length == 1) {
                if ($result[0] instanceof DOMDocument)
                    $result = [$result[0]->documentElement];
                if ($result[0] instanceof DOMAttr) {
                    $result = $result[0]->value;
                } else {
                    $xml = new DOMDocument();
                    $xml->appendChild($xml->importNode($result[0], true));
                    $result = $xml;
                }
            } else if ($result->length > 0) {
                $xml = new DOMDocument();
                $collection = $xml->createElement("collection");
                $xml->importNode($collection, true);
                foreach ($result as $entry) {
                    if ($entry instanceof DOMAttr)
                        $entry = $xml->createElement($entry->name, $entry->value);
                    $collection->appendChild($xml->importNode($entry, true));
                }
                $xml->appendChild($collection);
                $result = $xml;
            } else $result = "";
        } else if (is_bool($result)) {
            $result = $result ? "true" : "false";
        }

        $this->quit(200, "Success", null, $result);
    }

    function doPost() {

        if (!$this->exists())
            $this->quit(404, "Resource Not Found");

        if (!isset($_SERVER["CONTENT_TYPE"])
                || strcasecmp($_SERVER["CONTENT_TYPE"], Storage::CONTENT_TYPE_XML) !== 0)
            $this->quit(415, "Unsupported Media Type");

        if (preg_match(Storage::PATTERN_XPATH_FUNCTION, $this->xpath)) {
            $message = "Invalid XPath (Functions are not supported)";
            $this->quit(400, "Bad Request", ["Message" => $message]);
        }

        libxml_use_internal_errors(true);
        libxml_clear_errors();

        $style = new DOMDocument();
        $input = file_get_contents("php://input");
        if (empty($input)
                || !$style->loadXML($input)
                || Storage::fetchLastXmlErrorMessage()) {
            $message = "Invalid XSLT stylesheet";
            if (Storage::fetchLastXmlErrorMessage())
                $message .= " (" . Storage::fetchLastXmlErrorMessage() . ")";
            $this->quit(422, "Unprocessable Entity", ["Message" => $message]);
        }

        $processor = new XSLTProcessor();
        $processor->importStyleSheet($style);
        if (Storage::fetchLastXmlErrorMessage()) {
             $message = "Invalid XSLT stylesheet (" . Storage::fetchLastXmlErrorMessage() . ")";
             $this->quit(422, "Unprocessable Entity", ["Message" => $message]);
        }

        $xml = $this->xml;
        if (!empty($this->xpath)) {
            $xml = new DOMDocument();
            $targets = (new DOMXpath($this->xml))->query($this->xpath);
            if (Storage::fetchLastXmlErrorMessage()) {
                $message = "Invalid XPath axis (" . Storage::fetchLastXmlErrorMessage() . ")";
                $this->quit(400, "Bad Request", ["Message" => $message]);
            }
            if (!$targets || empty($targets) || $targets->length <= 0)
                $this->quit(404, "Resource Not Found");
            if ($targets->length == 1) {
                $target = $targets[0];
                if ($target instanceof DOMAttr)
                    $target = $xml->createElement($target->name, $target->value);
                $xml->appendChild($xml->importNode($target, true));
            } else {
                $collection = $xml->createElement("collection");
                $xml->importNode($collection, true);
                foreach ($targets as $target) {
                    if ($target instanceof DOMAttr)
                        $target = $xml->createElement($target->name, $target->value);
                    $collection->appendChild($xml->importNode($target, true));
                }
                $xml->appendChild($collection);
            }
        }

        $output = $processor->transformToXML($xml);
        if ($output === false
                || Storage::fetchLastXmlErrorMessage()) {
            $message = "Invalid XSLT stylesheet";
            if (Storage::fetchLastXmlErrorMessage())
                $message .= " (" . Storage::fetchLastXmlErrorMessage() . ")";
            $this->quit(422, "Unprocessable Entity", ["Message" => $message]);
        }

        $header = null;
        $method = (new DOMXpath($style))->evaluate("normalize-space(//*[local-name()='output']/@method)");
        if (!empty($output))
            if (strcasecmp($method, "xml") === 0
                    || empty($method))
                if (in_array("json", $this->options))
                    $output = simplexml_load_string($output);
                else $header = ["Content-Type" => Storage::CONTENT_TYPE_XML];
            else if (strcasecmp($method, "html") === 0)
                $header = ["Content-Type" => Storage::CONTENT_TYPE_HTML];
        $this->quit(200, "Success", $header, $output);
    }

    function doPut() {

        if (!$this->exists())
            $this->quit(404, "Resource Not Found");

        if (empty($this->xpath))
            $this->quit(400, "Bad Request", ["Message" => "Invalid XPath"]);

        if (strlen(file_get_contents("php://input")) > Storage::SPACE)
            $this->quit(413, "Payload Too Large");

        if (!isset($_SERVER["CONTENT_TYPE"]))
            $this->quit(415, "Unsupported Media Type");

        if (preg_match(Storage::PATTERN_XPATH_FUNCTION, $this->xpath)) {
            $message = "Invalid XPath (Functions are not supported)";
            $this->quit(400, "Bad Request", ["Message" => $message]);
        }

        libxml_use_internal_errors(true);
        libxml_clear_errors();

        if (preg_match(Storage::PATTERN_XPATH_ATTRIBUTE, $this->xpath, $matches, PREG_UNMATCHED_AS_NULL)) {

            if (!in_array(strtolower($_SERVER["CONTENT_TYPE"]), [Storage::CONTENT_TYPE_TEXT, Storage::CONTENT_TYPE_XPATH]))
                $this->quit(415, "Unsupported Media Type");

            $input = file_get_contents("php://input");

            if (strcasecmp($_SERVER["CONTENT_TYPE"], Storage::CONTENT_TYPE_XPATH) === 0) {
                if (!preg_match(Storage::PATTERN_XPATH_FUNCTION, $input)) {
                    $message = "Invalid XPath (Axes are not supported)";
                    $this->quit(422, "Unprocessable Entity", ["Message" => $message]);
                }
                $input = (new DOMXpath($this->xml))->evaluate($input);
                if ($input === false
                        || Storage::fetchLastXmlErrorMessage()) {
                    $message = "Invalid XPath function";
                    if (Storage::fetchLastXmlErrorMessage())
                        $message .= " (" . Storage::fetchLastXmlErrorMessage() . ")";
                    $this->quit(422, "Unprocessable Entity", ["Message" => $message]);
                }
            }

            $xpath = $matches[1];
            $attribute = $matches[2];

            $targets = (new DOMXpath($this->xml))->query($xpath);
            if (Storage::fetchLastXmlErrorMessage()) {
                $message = "Invalid XPath axis (" . Storage::fetchLastXmlErrorMessage() . ")";
                $this->quit(400, "Bad Request", ["Message" => $message]);
            }
            if (!$targets || empty($targets) || $targets->length <= 0)
                $this->quit(404, "Resource Not Found");

            if (!in_array($attribute, ["___rev", "___uid"])) {
                $serials = [];
                foreach ($targets as $target) {
                    if ($target->nodeType != XML_ELEMENT_NODE)
                        continue;
                    $serials[] = $target->getAttribute("___uid") . ":M";
                    $target->setAttribute($attribute, $input);
                    Storage::updateNodeRevision($target, $this->revision +1);
                }

                if (!empty($serials))
                    header("Storage-Effects: " . join(" ", $serials));
            }

            $this->materialize();
            $this->quit(204, "No Content");
        }

        if (!preg_match(Storage::PATTERN_XPATH_PSEUDO, $this->xpath, $matches, PREG_UNMATCHED_AS_NULL))
            $this->quit(400, "Bad Request", ["Message" => "Invalid XPath axis"]);

        $xpath = $matches[1];
        $pseudo = $matches[2];

        if (in_array(strtolower($_SERVER["CONTENT_TYPE"]), [Storage::CONTENT_TYPE_TEXT, Storage::CONTENT_TYPE_XPATH])) {

            if (!empty($pseudo))
                $this->quit(415, "Unsupported Media Type");

            $input = file_get_contents("php://input");

            if (strcasecmp($_SERVER["CONTENT_TYPE"], Storage::CONTENT_TYPE_XPATH) === 0) {
                if (!preg_match(Storage::PATTERN_XPATH_FUNCTION, $input)) {
                    $message = "Invalid XPath (Axes are not supported)";
                    $this->quit(422, "Unprocessable Entity", ["Message" => $message]);
                }
                $input = (new DOMXpath($this->xml))->evaluate($input);
                if ($input === false
                        || Storage::fetchLastXmlErrorMessage()) {
                    $message = "Invalid XPath function";
                    if (Storage::fetchLastXmlErrorMessage())
                        $message .= " (" . Storage::fetchLastXmlErrorMessage() . ")";
                    $this->quit(422, "Unprocessable Entity", ["Message" => $message]);
                }
            }

            $serials = [];
            $targets = (new DOMXpath($this->xml))->query($xpath);
            if (Storage::fetchLastXmlErrorMessage()) {
                $message = "Invalid XPath axis (" . Storage::fetchLastXmlErrorMessage() . ")";
                $this->quit(400, "Bad Request", ["Message" => $message]);
            }
            if (!$targets || empty($targets) || $targets->length <= 0)
                $this->quit(404, "Resource Not Found");

            foreach ($targets as $target) {
                if ($target->nodeType != XML_ELEMENT_NODE)
                    continue;
                $serials[] = $target->getAttribute("___uid") . ":M";
                $replace = $target->cloneNode(false);
                $replace->appendChild($this->xml->createTextNode($input));
                $target->parentNode->replaceChild($this->xml->importNode($replace, true), $target);
                Storage::updateNodeRevision($replace, $this->revision +1);
            }

            if (!empty($serials))
                header("Storage-Effects: " . join(" ", $serials));

            $this->materialize();
            $this->quit(204, "No Content");
        }

        if (strcasecmp($_SERVER["CONTENT_TYPE"], Storage::CONTENT_TYPE_XML) !== 0)
            $this->quit(415, "Unsupported Media Type");

        $input = file_get_contents("php://input");
        $input = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><data>$input</data>";

        $xml = new DOMDocument();
        if (!$xml->loadXML($input)
                || Storage::fetchLastXmlErrorMessage()) {
            $message = "Invalid XML document";
            if (Storage::fetchLastXmlErrorMessage())
                $message .= " (" . Storage::fetchLastXmlErrorMessage() . ")";
            $this->quit(422, "Unprocessable Entity", ["Message" => $message]);
        }

        $nodes = (new DOMXpath($xml))->query("//*[@___rev|@___uid]");
        foreach ($nodes as $node) {
            $node->removeAttribute("___rev");
            $node->removeAttribute("___uid");
        }

        $serials = [];
        if ($xml->documentElement->hasChildNodes()) {
            $targets = (new DOMXpath($this->xml))->query($xpath);
            if (Storage::fetchLastXmlErrorMessage()) {
                $message = "Invalid XPath axis (" . Storage::fetchLastXmlErrorMessage() . ")";
                $this->quit(400, "Bad Request", ["Message" => $message]);
            }
            if (!$targets || empty($targets) || $targets->length <= 0)
                $this->quit(404, "Resource Not Found");

            foreach ($targets as $target) {

                if ($target->nodeType != XML_ELEMENT_NODE)
                    continue;

                if (!empty($pseudo))
                    $pseudo = strtolower($pseudo);

                if (empty($pseudo)) {
                    $childs = (new DOMXpath($this->xml))->query(".//*[@___uid]", $target);
                    foreach ($childs as $child)
                        $serials[] = $child->getAttribute("___uid") . ":D";
                    $replace = $target->cloneNode(false);
                    foreach ($xml->documentElement->childNodes as $insert)
                        $replace->appendChild($this->xml->importNode($insert->cloneNode(true), true));
                    $target->parentNode->replaceChild($this->xml->importNode($replace, true), $target);
                } else if (strcmp($pseudo, "before") === 0) {
                    if ($target->parentNode->nodeType == XML_ELEMENT_NODE)
                        foreach ($xml->documentElement->childNodes as $insert)
                            $target->parentNode->insertBefore($this->xml->importNode($insert, true), $target);
                } else if (strcmp($pseudo, "after") === 0) {
                    if ($target->parentNode->nodeType == XML_ELEMENT_NODE) {
                        $nodes = [];
                        foreach($xml->documentElement->childNodes as $node)
                            array_unshift($nodes, $node);
                        foreach ($nodes as $insert)
                            if ($target->nextSibling)
                                $target->parentNode->insertBefore($this->xml->importNode($insert, true), $target->nextSibling);
                            else $target->parentNode->appendChild($this->xml->importNode($insert, true));
                    }
                } else if (strcmp($pseudo, "first") === 0) {
                    $inserts = $xml->documentElement->childNodes;
                    for ($index = $inserts->length -1; $index >= 0; $index--)
                        $target->insertBefore($this->xml->importNode($inserts->item($index), true), $target->firstChild);
                } else if (strcmp($pseudo, "last") === 0) {
                    foreach ($xml->documentElement->childNodes as $insert)
                        $target->appendChild($this->xml->importNode($insert, true));
                } else $this->quit(400, "Bad Request", ["Message" => "Invalid XPath axis (Unsupported pseudo syntax found)"]);
            }
        }

        $nodes = (new DOMXpath($this->xml))->query("//*[not(@___uid)]");
        foreach ($nodes as $node) {
            $serial = $this->getSerial();
            $serials[] = $serial . ":A";
            $node->setAttribute("___uid", $serial);
            Storage::updateNodeRevision($node, $this->revision +1);

            if ($node->parentNode->nodeType != XML_ELEMENT_NODE)
                continue;
            $serial = $node->parentNode->getAttribute("___uid");
            if (!empty($serial)
                    && !in_array($serial . ":A", $serials)
                    && !in_array($serial . ":M", $serials))
                $serials[] = $serial . ":M";
        }

        if (!empty($serials))
            header("Storage-Effects: " . join(" ", $serials));

        $this->materialize();
        $this->quit(204, "No Content");
    }

    function doPatch() {

        if (!$this->exists())
            $this->quit(404, "Resource Not Found");

        if (empty($this->xpath))
            $this->quit(400, "Bad Request", ["Message" => "Invalid XPath"]);

        if (strlen(file_get_contents("php://input")) > Storage::SPACE)
            $this->quit(413, "Payload Too Large");

        if (!isset($_SERVER["CONTENT_TYPE"]))
            $this->quit(415, "Unsupported Media Type");

        if (preg_match(Storage::PATTERN_XPATH_FUNCTION, $this->xpath)) {
            $message = "Invalid XPath (Functions are not supported)";
            $this->quit(400, "Bad Request", ["Message" => $message]);
        }

        libxml_use_internal_errors(true);
        libxml_clear_errors();

        $targets = (new DOMXpath($this->xml))->query($this->xpath);
        if (Storage::fetchLastXmlErrorMessage()) {
            $message = "Invalid XPath axis (" . Storage::fetchLastXmlErrorMessage() . ")";
            $this->quit(400, "Bad Request", ["Message" => $message]);
        }
        if (!$targets || empty($targets) || $targets->length <= 0)
            $this->quit(404, "Resource Not Found");

        $this->doPut();
    }

    function doDelete() {

        if (!$this->exists())
            $this->quit(404, "Resource Not Found");

        if (empty($this->xpath))
            $this->quit(400, "Bad Request", ["Message" => "Invalid XPath"]);

        if (preg_match(Storage::PATTERN_XPATH_FUNCTION, $this->xpath)) {
            $message = "Invalid XPath (Functions are not supported)";
            $this->quit(400, "Bad Request", ["Message" => $message]);
        }

        libxml_use_internal_errors(true);
        libxml_clear_errors();

        $pseudo = false;
        if (preg_match(Storage::PATTERN_XPATH_ATTRIBUTE, $this->xpath)) {
            $xpath = $this->xpath;
        } else {
            if (!preg_match(Storage::PATTERN_XPATH_PSEUDO, $this->xpath, $matches, PREG_UNMATCHED_AS_NULL))
                $this->quit(400, "Bad Request", ["Message" => "Invalid XPath axis"]);
            $xpath = $matches[1];
            $pseudo = $matches[2];
        }

        $targets = (new DOMXpath($this->xml))->query($xpath);
        if (Storage::fetchLastXmlErrorMessage()) {
            $message = "Invalid XPath axis (" . Storage::fetchLastXmlErrorMessage() . ")";
            $this->quit(400, "Bad Request", ["Message" => $message]);
        }

        if (!$targets || empty($targets) || $targets->length <= 0)
            $this->quit(404, "Resource Not Found");

        if ($pseudo) {
            if (strcasecmp($pseudo, "before") === 0) {
                $childs = [];
                foreach ($targets as $target) {
                    if (!$target->previousSibling)
                        continue;
                    for ($previous = $target->previousSibling; $previous; $previous = $previous->previousSibling)
                        $childs[] = $previous;
                }
                $targets = $childs;
            } else if (strcasecmp($pseudo, "after") === 0) {
                $childs = [];
                foreach ($targets as $target) {
                    if (!$target->nextSibling)
                        continue;
                    for ($next = $target->nextSibling; $next; $next = $next->nextSibling)
                        $childs[] = $next;
                }
                $targets = $childs;
            } else if (strcasecmp($pseudo, "first") === 0) {
                $childs = [];
                foreach ($targets as $target)
                    if ($target->firstChild)
                        $childs[] = $target->firstChild;
                $targets = $childs;
            } else if (strcasecmp($pseudo, "last") === 0) {
                $childs = [];
                foreach ($targets as $target)
                    if ($target->lastChild)
                        $childs[] = $target->lastChild;
                $targets = $childs;
            } else $this->quit(400, "Bad Request", ["Message" => "Invalid XPath axis (Unsupported pseudo syntax found)"]);
        }

        $serials = [];
        foreach ($targets as $target) {
            if ($target->nodeType === XML_ATTRIBUTE_NODE) {
                if (!$target->parentNode
                        || $target->parentNode->nodeType !== XML_ELEMENT_NODE
                        || in_array($target->name, ["___rev", "___uid"]))
                    continue;
                $parent = $target->parentNode;
                $parent->removeAttribute($target->name);
                $serials[] = $parent->getAttribute("___uid") . ":M";
                Storage::updateNodeRevision($parent, $this->revision +1);
            } else if ($target->nodeType !== XML_DOCUMENT_NODE) {
                if (!$target->parentNode
                        || !in_array($target->parentNode->nodeType, [XML_ELEMENT_NODE, XML_DOCUMENT_NODE]))
                    continue;
                if ($target instanceof DOMElement) {
                    $serials[] = $target->getAttribute("___uid") . ":D";
                    $nodes = (new DOMXpath($this->xml))->query(".//*[@___uid]", $target);
                    foreach ($nodes as $node)
                        $serials[] = $node->getAttribute("___uid") . ":D";
                }
                $parent = $target->parentNode;
                $parent->removeChild($target);
                if ($parent->nodeType === XML_DOCUMENT_NODE) {
                    $target = $this->xml->createElement($this->root);
                    $target = $this->xml->appendChild($target);
                    Storage::updateNodeRevision($target, $this->revision +1);
                    $serial = $this->getSerial();
                    $serials[] = $serial . ":A";
                    $target->setAttribute("___uid", $serial);
                } else {
                    $serials[] = $parent->getAttribute("___uid") . ":M";
                    Storage::updateNodeRevision($parent, $this->revision +1);
                }
            }
        }

        if (!empty($serials))
            header("Storage-Effects: " . join(" ", $serials));

        $this->materialize();
        $this->quit(204, "No Content");
    }

    function quit($status, $message, $headers = null, $data = null) {

        if (headers_sent()) {
            $this->close();
            exit;
        }

        $fetchHeader = function($name, $remove = false) {
            $result = false;
            foreach (headers_list() as $header) {
                if (!preg_match("/^\s*" . $name . "\s*:/i", $header))
                    continue;
                preg_match("/^\s*(.*?)\s*:\s*(.*)\s*$/", $header, $header, PREG_UNMATCHED_AS_NULL);
                if ($remove) {
                    header($header[1] . ":");
                    header_remove($header[1]);
                }
                $result = (object)["name" => $header[1], "value" => $header[2]];
            }
            return $result;
        };

        header(trim("HTTP/1.0 $status $message"));

        header("Content-Type:");
        header("Content-Length:");

        $filter = ["X-Powered-By", "Content-Type", "Content-Length"];
        foreach ($filter as $header)
            $fetchHeader($header, true);

        if (!empty(Storage::CORS))
            foreach (Storage::CORS as $key => $value)
                header("$key: $value");

        if ($_SERVER["REQUEST_METHOD"] == "OPTIONS") {
            if (isset($_SERVER["HTTP_ACCESS_CONTROL_REQUEST_METHOD"]))
                header("Access-Control-Allow-Methods: CONNECT, OPTIONS, GET, POST, PUT, PATCH, DELETE");
            if (isset($_SERVER["HTTP_ACCESS_CONTROL_REQUEST_HEADERS"]))
                header("Access-Control-Allow-Headers: {$_SERVER["HTTP_ACCESS_CONTROL_REQUEST_HEADERS"]}");
        }

        if (!$headers)
            $headers = [];

        if ($status >= 200 && $status < 300
                && $this->storage
                && $this->xml) {
            $expiration = new DateTime();
            $expiration->add(new DateInterval("PT" . Storage::TIMEOUT . "S"));
            $expiration = $expiration->format("D, d M Y H:i:s T");
            $headers = array_merge($headers, [
                "Storage" => $this->storage,
                "Storage-Revision" => $this->xml->documentElement->getAttribute("___rev"),
                "Storage-Space" => Storage::SPACE . "/" . $this->getSize() . " bytes",
                "Storage-Last-Modified" => date("D, d M Y H:i:s T"),
                "Storage-Expiration" => $expiration,
                "Storage-Expiration-Time" => (Storage::TIMEOUT *1000) . " ms"
            ]);
        }

        $serials = $fetchHeader("Storage-Effects", true);
        $serials = $serials ? $serials->value : "";
        if (!empty($serials)) {
            $serials = preg_split("/\s+/", $serials);
            $serials = array_unique($serials);
            foreach ($serials as $serial) {
                if (substr($serial, -2) !== ":D")
                    continue;
                $search = substr($serial, 0, -2) . ":M";
                if (in_array($search, $serials))
                    unset($serials[array_search($search, $serials)]);
                $search = substr($serial, 0, -2) . ":A";
                if (in_array($search, $serials))
                    unset($serials[array_search($search, $serials)]);
            }
            $serials = implode(" ", $serials);
        }

        $accepts = isset($_SERVER["HTTP_ACCEPT_EFFECTS"]) ? strtolower(trim($_SERVER["HTTP_ACCEPT_EFFECTS"])) : "";
        $accepts = !empty($accepts) ? preg_split("/\s+/", $accepts) : [];
        $pattern = [];
        if (strtoupper($_SERVER["REQUEST_METHOD"]) !== "DELETE") {
            if (!empty($accepts)
                    && !in_array("added", $accepts))
                $pattern[] = "A";
            if (empty($accepts)
                    || !in_array("deleted", $accepts))
                $pattern[] = "D";
        } else {
            if (empty($accepts)
                    || !in_array("added", $accepts))
                $pattern[] = "A";
            if (!empty($accepts)
                    && !in_array("deleted", $accepts))
                $pattern[] = "D";
        }
        if (!empty($accepts)
                && !in_array("modified", $accepts))
            $pattern[] = "M";
        if (!empty($accepts)
                && in_array("none", $accepts))
            $pattern = ["A", "M", "D"];
        if (!empty($accepts)
                && in_array("all", $accepts))
            $pattern = [];
        if (!empty($pattern))
            $serials = preg_replace("/\s*\w+:\w+:[" . implode("|", $pattern) . "]\s*/i", " ", $serials);
        $serials = trim(preg_replace("/\s{2,}/", " ", $serials));
        if (!empty($serials))
            header("Storage-Effects: " . $serials);

        foreach ($headers as $key => $value) {
            if (strcasecmp($key, "Content-Length") === 0)
                continue;
            $value = trim(preg_replace("/[\r\n]+/", " ", $value));
            if (strlen(trim($value)) > 0)
                header("$key: $value");
            else header_remove($key);
        }

        $media = $fetchHeader("Content-Type", true);
        if ($status == 200
                && $data !== ""
                && $data !== null) {
            if (!$media) {
                if (in_array("json", $this->options)) {
                    $media = Storage::CONTENT_TYPE_JSON;
                    if ($data instanceof DOMDocument
                            || $data instanceof SimpleXMLElement)
                        $data = simplexml_import_dom($data);
                    $data = json_encode($data, JSON_UNESCAPED_SLASHES);
                } else {
                    if ($data instanceof DOMDocument
                            || $data instanceof SimpleXMLElement) {
                        $media = Storage::CONTENT_TYPE_XML;
                        $data = $data->saveXML();
                    } else $media = Storage::CONTENT_TYPE_TEXT;
                }
            } else $media = $media->value;
            header("Content-Type: $media");
        }

        if ($status >= 200 && $status < 300)
            if (($data !== "" && $data !== null)
                    || $status == 200)
                header("Content-Length: " . strlen($data));

        $headers = array_change_key_case($headers, CASE_LOWER);
        if (in_array($status, [201, 202, 405])
                && !array_key_exists("allow", $headers))
            header("Allow: CONNECT, OPTIONS, GET, POST, PUT, PATCH, DELETE");

        header("Execution-Time: " . round((microtime(true) -$_SERVER["REQUEST_TIME_FLOAT"]) *1000) . " ms");

        if ($status >= 200 && $status < 300
                && $data !== "" && $data !== null)
            print($data);

        $this->close();
        exit;
    }

    private static function fetchLastXmlErrorMessage() {

        if (empty(libxml_get_errors()))
            return false;
        $message = libxml_get_errors();
        $message = end($message)->message;
        $message = preg_replace("/[\r\n]+/", " ", $message);
        $message = preg_replace("/\.+$/", " ", $message);
        return trim($message);
    }

    static function onError($error, $message, $file, $line, $vars = array()) {

        $filter = "XSLTProcessor::transformToXml()";
        if (substr($message, 0, strlen($filter)) === $filter) {
            $message = "Invalid XSLT stylesheet";
            if (Storage::fetchLastXmlErrorMessage())
                $message .= " (" . Storage::fetchLastXmlErrorMessage() . ")";
            (new Storage)->quit(422, "Unprocessable Entity", ["Message" => $message]);
        }

        $unique = "#" . Storage::uniqueId();
        $message = "$message" . PHP_EOL . "\tat $file $line";
        if (!is_numeric($error))
            $message = "$error:" . $message;
        $time = time();
        file_put_contents(date("Ymd", $time) . ".log", date("Y-m-d H:i:s", $time) . " $unique $message" . PHP_EOL, FILE_APPEND | LOCK_EX);
        (new Storage)->quit(500, "Internal Server Error", ["Error" => $unique]);
    }

    static function onException($exception) {
        Storage::onError(get_class($exception), $exception->getMessage(), $exception->getFile(), $exception->getLine());
    }
}

date_default_timezone_set ("GMT");
set_error_handler("Storage::onError");
set_exception_handler("Storage::onException");

$script = basename(__FILE__);
if (isset($_SERVER["PHP_SELF"])
        && preg_match("/\/" . str_replace(".", "\\.", $script) . "([\/\?].*){0,1}$/", $_SERVER["PHP_SELF"])
        && (!isset($_SERVER["REDIRECT_URL"])
                || empty($_SERVER["REDIRECT_URL"])))
    (new Storage)->quit(404, "Resource Not Found");

$method = strtoupper($_SERVER["REQUEST_METHOD"]);

if ($method === "OPTIONS"
        && isset($_SERVER["HTTP_ORIGIN"])
        && !isset($_SERVER["HTTP_STORAGE"]))
    (new Storage)->quit(200, "Success");

$storage = null;
if (isset($_SERVER["HTTP_STORAGE"]))
    $storage = $_SERVER["HTTP_STORAGE"];
if (!preg_match(Storage::PATTERN_HEADER_STORAGE, $storage))
    (new Storage)->quit(400, "Bad Request", ["Message" => "Invalid storage identifier"]);

$xpath = $_SERVER["REQUEST_URI"];
if (Storage::PATTERN_HTTP_REQUEST_URI) {
    if (isset($_SERVER["REQUEST"])
            && preg_match(Storage::PATTERN_HTTP_REQUEST, $_SERVER["REQUEST"], $xpath, PREG_UNMATCHED_AS_NULL))
        $xpath = $xpath[2];
    $xpath = preg_match(Storage::PATTERN_HTTP_REQUEST_URI, $xpath, $xpath, PREG_UNMATCHED_AS_NULL) ? $xpath[2] : "";
}
if (preg_match("/^0x([A-Fa-f0-9]{2})+$/", $xpath))
    $xpath = hex2bin(substr($xpath, 2));
else if (preg_match("/^Base64:[A-Za-z0-9\+\/]+=*$/", $xpath))
    $xpath = base64_decode(substr($xpath, 7));
else $xpath = urldecode($xpath);

if (empty($xpath)
        && !in_array($method, ["CONNECT", "OPTIONS", "POST"]))
    $xpath = "/";
$exclusive = in_array($method, ["DELETE", "PATCH", "PUT"]);
$storage = Storage::share($storage, $xpath, $exclusive);

try {
    switch ($method) {
        case "CONNECT":
            $storage->doConnect();
        case "OPTIONS":
            $storage->doOptions();
        case "GET":
            $storage->doGet();
        case "POST":
            $storage->doPost();
        case "PUT":
            $storage->doPut();
        case "PATCH":
            $storage->doPatch();
        case "DELETE":
            $storage->doDelete();
        default:
            $storage->quit(405, "Method Not Allowed");
    }
} finally {
    $storage->close();
}
?>